alert('welkom onze site');


var getal = parseInt(prompt ('voer getal in'))

document.write(getal*12);
document.write("<br   />");

var voornaam = prompt ('voer je voornaam in. let op deze info slaan wij op in onze database')
document.write("je voornaam: "); document.write(voornaam); 
document.write("<br   />"); 
var achternaam = prompt ('voor je achternaam in. let op deze info slaan wij op in onze database')
document.write("je achternaam:"); document.write(achternaam); 
document.write("<br   />"); 
var leeftijd = prompt ('voer je leeftijd in. let op deze info slaan wij op in onze database')
document.write("je leeftijd: "); document.write(leeftijd); 
document.write("<br   />"); 
document.write('nog ' )
var x = 18;
var y = leeftijd;
var z = x - y;
document.write (z+' jaren tot dat je 18 bent')
document.write('<br/>')

document.write('12+6=18x10=180:5=36-12=24')







document.write ('<br/>')
document.write ('6x1='+ (6*1));
document.write ('<br/>')
document.write ('6x2='+ (6*2));
document.write ('<br/>')
document.write ('6x3='+ (6*3));
document.write ('<br/>')
document.write ('6x4='+ (6*4));
document.write ('<br/>')
document.write ('6x5='+ (6*5));
document.write ('<br/>')
document.write ('6x6='+ (6*6));
document.write ('<br/>')
document.write ('6x7='+ (6*7));
document.write ('<br/>')
document.write ('6x8='+ (6*8));
document.write ('<br/>')
document.write ('6x9='+ (6*9));
document.write ('<br/>')
document.write ('6x10='+ (6*10));
document.write ('<br/>')


document.write ('<br/>')
document.write ('3x1='+ (3*1));
document.write ('<br/>')
document.write ('3x2='+ (3*2));
document.write ('<br/>')
document.write ('3x3='+ (3*3));
document.write ('<br/>')
document.write ('3x4='+ (3*4));
document.write ('<br/>')
document.write ('3x5='+ (3*5));
document.write ('<br/>')
document.write ('3x6='+ (3*6));
document.write ('<br/>')
document.write ('3x7='+ (3*7));
document.write ('<br/>')
document.write ('3x8='+ (3*8));
document.write ('<br/>')
document.write ('3x9='+ (3*9));
document.write ('<br/>')
document.write ('3x10='+ (3*10));
document.write ('<br/>')









