document.write('1X6'1*6)
