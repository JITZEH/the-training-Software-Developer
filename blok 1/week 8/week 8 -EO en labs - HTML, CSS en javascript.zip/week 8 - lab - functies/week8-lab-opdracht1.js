function hallo(){ 

   document.write(" <ol> Hallo Wereld! </ol>" );

}
 

for (var i = 1; i <= 3; i++) {
hallo();	
}

document.write ('<br>')
document.write ('<br>')

for (var i = 1; i <= 7; i++) {
hallo();	
}



