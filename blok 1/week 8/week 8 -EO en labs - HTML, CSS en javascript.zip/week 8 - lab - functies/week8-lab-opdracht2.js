//OPTEL 1
function optel(a,b) {
return a+b
}

document.write ('10 + 12 =' );
document.write(optel(10,12));
document.write('<br>');


//AFREK 1
function aftrek(a,b) {
return a-b
}

document.write ('58 - 34 = ');
document.write(aftrek(58,34));
document.write('<br>');


//KEER
function keer(a,b) {
return a*b
}

document.write ('6 x 7 = n' );
document.write(keer(6,7));
document.write('<br>');


//DEEL
function deel(a,b) {
return a/b
}

document.write ('144 : 12 = ' );
document.write(deel(144,12));
document.write('<br>');


//OPTEL 2
document.write ('12 + 1 = ' );
document.write(optel(12,1));
document.write('<br>');

//AFTREK 2
document.write ('34 - 1 = ' );
document.write(aftrek(34,1));
document.write('<br>');
