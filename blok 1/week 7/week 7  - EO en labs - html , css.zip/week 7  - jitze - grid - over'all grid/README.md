week 7  - jitze - grid - over'all grid
