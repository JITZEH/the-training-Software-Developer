week 5  - div leren - lab - jitze
